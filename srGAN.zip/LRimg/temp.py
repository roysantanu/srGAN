from datetime import datetime
(dt, micro) = datetime.utcnow().strftime('%Y%m%d%H%M%S.%f').split('.')
print ("%s%03d" % (dt, int(micro) / 1000))